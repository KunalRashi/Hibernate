package RelationshipOneMany;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class LogicOneMany {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		
		Vendor v = new Vendor();
		v.setVid(102);
		v.setVname("Shiva");
		
		Customer c1 = new Customer();
		c1.setCid(4);
		c1.setCname("Romil");
		

		Customer c2 = new Customer();
		c2.setCid(5);
		c2.setCname("Arjun");
		

		Customer c3 = new Customer();
		c3.setCid(6);
		c3.setCname("Nihal");
      
		Set se =new HashSet();
		
		se.add(c1);
		se.add(c2);
		se.add(c3);
		
	    v.setChildren(se);
	    
	    Transaction tx = s.beginTransaction();
	
		s.save(v);
		tx.commit();
		s.close();
		
		System.out.println("One To Many is Done");
		 
		 sf.close();
	}

}
