package RelationshipOneMany;

public class Customer {
      private int cid;
      private String cname;
      private int fkvid;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getFkvid() {
		return fkvid;
	}
	public void setFkvid(int fkvid) {
		this.fkvid = fkvid;
	}
      
}
