package scs;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class AdminLogin {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
       Configuration cfg = new Configuration();
       cfg.configure("hibernate.cfg.xml");
       SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		
		Query q= s.createQuery("from Login obj where obj.userid=? and obj.password=?");
		String uid;
		String upass;
		System.out.println("Enter userid");
		uid = sc.next();
		
		System.out.println("Enter password");
		upass = sc.next();
		
		q.setString(0, uid);
		q.setString(1, upass);
		
		List lst = q.list();
		
		if(lst.size()>0)
		{
			System.out.println("Login Successfully");
			
		}			 
			
		
		else
		{
			System.out.println("Invalid userid and password");
		}
		s.close();
	}

}
