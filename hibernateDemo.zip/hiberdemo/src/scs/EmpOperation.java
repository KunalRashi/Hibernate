package scs;
import java.util.Scanner;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmpOperation {
	Configuration cfg;
	SessionFactory sf;
	Session s;
	
	void configureHiber()
	{
		cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		sf=cfg.buildSessionFactory();
		s=sf.openSession();
		
	}
	
	void insertHiber(int empid,String empname,String job, int sal)
	{
		Transaction tx = s.beginTransaction();
		Emp e= new Emp();
		e.setEmpid(empid);
		e.setEmpname(empname);
		e.setJob(job);
		e.setSalary(sal);
        s.save(e);
        tx.commit();
	}
	
	void updateHiber()
	{
		Transaction tx = s.beginTransaction();
		Object o = s.get(Emp.class, new Integer(1002));
		Emp e = (Emp)o; //downcasting
		e.setEmpid(1002);
		e.setEmpname("Tarun");
		e.setJob("Manager");
		e.setSalary(120000);
		s.update(e);
		tx.commit();	
	}
   
	 void deleteHiber()
	 {
		 Transaction tx = s.beginTransaction();
		 Object o = s.get(Emp.class, new Integer(1001));
		 Emp e =(Emp)o;
		 s.delete(e);
		 tx.commit();
	 }
	 
	 void displayHiber() // select
	 {
		 Query q= s.createQuery("from Emp obj");
		 List lst = q.list();
		 Iterator it =lst.iterator();
		 while(it.hasNext())
		 {
			 Emp o = (Emp)it.next();
		    System.out.println(o.getEmpid()+" "+ o.getEmpname()+" "+ o.getJob()+" "+ o.getSalary());
		    
		 }
	 }
	 void closeConfiguration()
	 {
		 s.close();
	 }
	 
	 public static void main(String arg[])
	 {
		 EmpOperation obj = new EmpOperation();
		 obj.configureHiber();
		 System.out.println("Press 1 for insert, 2 for update,3  for delete");
		 switch(3)
		 {
		 case 1:
			 obj.insertHiber(1009,"Surj", "Peon", 10000);
			 obj.displayHiber();
			 break;
			 
		 case 2:
			 obj.updateHiber();
			 obj.displayHiber();
			 break;
			
		 case 3:
			 obj.deleteHiber();
			 obj.displayHiber();
			 break;
		
			 
		 }
		 obj.closeConfiguration();
	 }
}
